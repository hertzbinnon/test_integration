/* Omitted from MPE. */

#define MAXHOSTNAMELEN	64
#define MAXPATHLEN	1024
