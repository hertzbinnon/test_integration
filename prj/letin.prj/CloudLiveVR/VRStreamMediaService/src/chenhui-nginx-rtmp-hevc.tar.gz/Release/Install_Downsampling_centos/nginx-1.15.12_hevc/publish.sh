ffmpeg -i $1 -c copy -f flv $2
