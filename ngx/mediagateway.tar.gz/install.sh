#!/bin/bash
INSTALL_PATH=/tmp/ITVLT
VERSION=0.0.4-CentOS74
check_root()
{
    if [ "root" != "$USER" ]; then
        echo "Permission denied! Please use root try again."
        exit 0;
    fi
}
check_root;
let major=`cat /etc/redhat-release | grep -oE "[0-9.]+" | cut -d . -f1`
let minor=`cat /etc/redhat-release | grep -oE "[0-9.]+" | cut -d . -f2`
#let threads=`cat /proc/cpuinfo | grep "physical id" | uniq | wc -l`
#HZ=`cat /proc/cpuinfo | grep "model name" | uniq | cut -d @ -f2 | grep -oE "[0-9.]+"`
#cat /proc/meminfo | grep "MemTotal" | uniq | cut -d @ -f2 | grep -oE "[0-9.]+"
if [ $major -lt 7 -o $minor -lt 4 ];then
        echo "System must be centos7 7.4 or after"
		exit 0;
fi
rm -rf $INSTALL_PATH/

if [ ! -d $INSTALL_PATH ]; then
        mkdir -p $INSTALL_PATH
fi
if [ ! -d $INSTALL_PATH ]; then
        echo "Create install path error"
        exit 1;
fi
basepath=$(cd `dirname $0`; pwd)
pushd  $INSTALL_PATH > /dev/null
    ARCHIVE=`awk '/^__ARCHIVE_BELOW__/ {print NR + 1; exit 0; }' $basepath/$0`
    tail -n+$ARCHIVE $basepath/$0 | tar xz
popd  > /dev/null
if [ $? != 0 ]; then
        echo "unpack error."
        exit 1;
fi
cd $INSTALL_PATH
cp -f $INSTALL_PATH/bin/mediagateway /usr/bin/mediagateway
cp -f $INSTALL_PATH/etc/mgwd /etc/init.d/
cp -f $INSTALL_PATH/etc/mediagateway.conf /etc/
cp -f $INSTALL_PATH/modules/* /usr/local/lib/
rm -rf $INSTALL_PATH/
#rm -f /tmp/mgwd.logs
#cp -f $INSTALL_PATH/etc/smsx.conf /etc/
#rm -f $INSTALL_PATH/etc/smsx.conf
#rm -f $INSTALL_PATH/bin/mediagateway
#rm -f $INSTALL_PATH/etc/mgwd
#touch  /etc/ld.so.conf.d/smsx.conf
#echo $INSTALL_PATH/modules > /etc/ld.so.conf.d/smsx.conf
#ldconfig -v > /dev/null 2>&1
exit 0;
__ARCHIVE_BELOW__
