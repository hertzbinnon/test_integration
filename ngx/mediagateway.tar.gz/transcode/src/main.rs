use std::env;
use std::process::Command;
extern crate libc;
use libc::c_char;
use libc::c_int;
use std::ffi::CString;
#[link(name="rtmp_encoder")]
extern "C" {
	fn avconv_main(argc: c_int, argv: *const *const c_char ) -> c_int;
}
//#[macro_use] 
//extern crate json_derive;
use std::fs::File;
use std::io::Read;
use std::io::Write;


fn string_array_to_c(strs: Vec<String>) -> *const *const c_char {
    let len = strs.len();

    let mut result : Vec<*const c_char> = Vec::with_capacity(len + 1);
    for str in strs.into_iter() {
        let el = CString::new(str).unwrap().into_raw() as *const c_char;

        result.push(el);
    }

    result.push(std::ptr::null());
    let result = result.into_boxed_slice();
    Box::into_raw(result) as *const *const c_char
}

fn main() {
//////////////////////////////////////////////////////////////////////////////////
	let args: Vec<String> = env::args().collect();
	let mut v;
	println!("{:?}",args);
	if args.len() == 4{
		let url = &args[1];
		let url_out= &args[2];
		let bitrate = &args[3];
		let bufsize = bitrate.parse::<i32>().unwrap();
		let bufsize = bufsize / 25;
		let bufsize = bufsize.to_string();
		println!{"{}{}{}{}",url,url_out,bitrate,bufsize};
		v = vec!["itvenc".to_string(),
							"-v".to_string(),"debug".to_string(),
							//"-threads".to_string(), "1".to_string(),
							"-i".to_string(),url.to_string(),
							"-c:v".to_string(),"libx264".to_string(), 
							"-r".to_string(),"25".to_string(),
							//"-r".to_string(),"25".to_string(),
							//"-preset".to_string(),"ultrafast".to_string(),"-tune".to_string(), "fastdecode".to_string(),
							//"-x264-params".to_string(),"nal-hrd=cbr:keyint=25:min-keyint=25:scenecut=0".to_string(),
							"-x264-params".to_string(),"nal-hrd=cbr:keyint=25:min-keyint=25:scenecut=0:bframes=0:colorprim=bt709:colormatrix=bt709:transfer=bt709".to_string(),
							//"-x264-params".to_string(),"keyint=25:min-keyint=25:scenecut=0".to_string(),
							"-b:v".to_string(),bitrate.to_string(),"-minrate".to_string(),bitrate.to_string(),"-maxrate".to_string(),bitrate.to_string(),"-bufsize".to_string(),bufsize.to_string(),
							//"-threads".to_string(),"24".to_string(),
							"-c:a".to_string(),
							"libfdk_aac".to_string(),"-b:a".to_string(),"128k".to_string(),"-f".to_string(),"flv".to_string(),url_out.to_string()];
	}else {
		let url = &args[1];
		let url_out= &args[2];
		v = vec!["itvenc".to_string(),"-v".to_string(),"quiet".to_string(),"-re".to_string(),"-stream_loop".to_string(),"-1".to_string(), 
				"-i".to_string(),url.to_string(),
				"-c:v".to_string(),"copy".to_string(),
				"-c:a".to_string(),"copy".to_string(),
				"-f".to_string(),"flv".to_string(),url_out.to_string()];
	}
	let len = v.len();
	let mut log= File::create("/tmp/note.mgwd").unwrap();
	write!(log,"{:?}",v);
	let v = string_array_to_c(v);
 	unsafe { 
		avconv_main(len as c_int,v); 
	}
	println!("{:?}",v);
	write!(log,"{}","quite");
}
