#!/bin/bash
VERSION=`grep VERSION install.sh | head -1`
VERSION=`echo $VERSION | cut -d \= -f2`
PACKAGENAME=mediagateway-$VERSION-setup.bin
ARCHIVEFILE=lanting.tar.gz
MODULES_PATH=
check_root()
{
    if [ "root" != "$USER" ]; then
        echo "Permission denied! Please use root try again."
        exit 0;
    fi
}
check_root;
basepath=$(cd `dirname $0`; pwd)
ngx_project_path=/home/nginx
ngx_version=1.14.0
ngx_root_path=$ngx_project_path/nginx-$ngx_version
ngx_prefix="/usr/share/lanTing"
ngx_config_path="conf/ngx.conf"
#ngx_exec="itvginx-fe2972174243fce9bd5c93dd1b3970e102805087aa3ca5b0f23de1ccd7304582c5d61fd3d9b3556a845e69177f8da547679cc7da3eb30a1b77a65feee27516f3"
ngx_exec="itvginx-6617cd28a37d6c3108c131bea3c509a56b674a4d26484295b7aa6d9678da331be6f29d96d0bc1b2cc2b72ac73d9a432205f1f4864c6a338aadfd7609b6096c40"
#itv_enc="itvenc-0bba57d3529e8c3a05994ca2c2831955c1472dcce79a7ed22f3d1104bb74e7e7f96efdc60643afd6b00068efccfdbed02dfea5e0f19fbae7aab9bfc8f01eb57e"
itv_enc="itvenc-8732dfb39c3f9a3d258e3d1937731e91b0e63536edb75dd84d40557e926d967c1764101b9f404d12b3aef572bdd9df2a82f5d8072562dc2f39209dff502aa753"
cd $ngx_root_path
#./nginx_configure.sh $ngx_project_path $ngx_prefix $ngx_config_path
#make 
echo "cp objs/nginx $basepath/org"
cp objs/nginx $basepath/org/$ngx_exec
cd - > /dev/null

#rm -f $PACKAGENAME
export PKG_CONFIG_PATH=/home/cerbero-1.14/build/dist/linux_x86_64/lib/pkgconfig:/usr/local/lib/pkgconfig
gcc `pkg-config --libs  --cflags glib-2.0 libgtop-2.0 json-glib-1.0 libsoup-2.4` proxy.c `pkg-config --libs  --cflags glib-2.0 libgtop-2.0 json-glib-1.0 libsoup-2.4` \
    -DITV_GINX_OFFSET=34765425 -DITV_ENC_OFFSET=34765425 \
    -DNGX_PREFIX=\"$ngx_prefix\" -DNGX_EXEC_NAME=\"$ngx_exec\" -DNGX_CONFIG_PATH=\"$ngx_config_path\" -DNGX_MIME_PATH=\"conf/mime.types\" \
    -DENC_EXEC_NAME=\"$itv_enc\" \
    -o proxy_temp
let itvginx_length=`ls -l org/$ngx_exec | grep -oE "[0-9]+" | sed -n '2p'`
let itvginx_offset=`ls -l proxy_temp | grep -oE "[0-9]+" | sed -n '2p'`
let itvenc_offset=itvginx_offset+itvginx_length
gcc `pkg-config --libs  --cflags glib-2.0 libgtop-2.0 json-glib-1.0 libsoup-2.4` proxy.c `pkg-config --libs  --cflags glib-2.0 libgtop-2.0 json-glib-1.0 libsoup-2.4` \
	-DITV_GINX_OFFSET=$itvginx_offset -DITV_ENC_OFFSET=$itvenc_offset \
    -DNGX_PREFIX=\"$ngx_prefix\" -DNGX_EXEC_NAME=\"$ngx_exec\" -DNGX_CONFIG_PATH=\"$ngx_config_path\" -DNGX_MIME_PATH=\"conf/mime.types\" \
    -DENC_EXEC_NAME=\"$itv_enc\" \
	 -o org/proxy
cat org/{proxy,$ngx_exec,$itv_enc} > bin/mediagateway
chmod 777 bin/mediagateway
rm -f proxy_temp

tar zcf $ARCHIVEFILE bin etc modules
cat install.sh $ARCHIVEFILE  > $PACKAGENAME
rm $ARCHIVEFILE
chmod a+x $PACKAGENAME
